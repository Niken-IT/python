# Solving-tasks-for-Python
Задание были выполнены с помощью программы Visual Studio